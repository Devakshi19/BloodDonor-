plugins {
    alias(libs.plugins.android.application)
}

android {
    namespace = "com.example.blooddonor"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.blooddonor"
        minSdk = 24
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        debug {
            isDebuggable = true   // ← Required for Database Inspector to work
        }
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }
}

dependencies {
    implementation(libs.appcompat)
    implementation(libs.material)
    implementation(libs.activity)
    implementation(libs.constraintlayout)
    implementation("androidx.core:core-splashscreen:1.0.1")

    // RecyclerView – for donor lists, request lists, history, etc.
    implementation("androidx.recyclerview:recyclerview:1.3.2")

    // CardView – for beautiful card-style UI components
    implementation("androidx.cardview:cardview:1.0.0")

    // CircleImageView – for round profile pictures
    implementation("de.hdodenhof:circleimageview:3.1.0")

    // Fragment support – for bottom navigation tabs
    implementation("androidx.fragment:fragment:1.6.2")

    testImplementation(libs.junit)
    androidTestImplementation(libs.ext.junit)
    androidTestImplementation(libs.espresso.core)
}