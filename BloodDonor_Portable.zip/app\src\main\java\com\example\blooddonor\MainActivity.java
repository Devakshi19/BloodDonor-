package com.example.blooddonor;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.example.blooddonor.utils.SessionManager;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        SessionManager session = new SessionManager(this);
        if (session.isLoggedIn()) {
            startActivity(new android.content.Intent(this, DashboardActivity.class));
        } else {
            startActivity(new android.content.Intent(this, LoginActivity.class));
        }
        finish();
    }
}