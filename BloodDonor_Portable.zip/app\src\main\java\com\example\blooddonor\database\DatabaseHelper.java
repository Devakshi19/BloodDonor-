package com.example.blooddonor.database;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME    = "blood_donor.db";
    private static final int    DATABASE_VERSION = 1;

    public static final String TABLE_USERS            = "users";
    public static final String TABLE_BLOOD_REQUESTS   = "blood_requests";
    public static final String TABLE_DONATION_HISTORY = "donation_history";

    public static final String COL_USER_ID            = "id";
    public static final String COL_USER_UID           = "uid";
    public static final String COL_USER_NAME          = "full_name";
    public static final String COL_USER_EMAIL         = "email";
    public static final String COL_USER_PHONE         = "phone";
    public static final String COL_USER_PASSWORD      = "password";
    public static final String COL_USER_BLOOD_GROUP   = "blood_group";
    public static final String COL_USER_TYPE          = "user_type";
    public static final String COL_USER_LATITUDE      = "latitude";
    public static final String COL_USER_LONGITUDE     = "longitude";
    public static final String COL_USER_LAST_DONATION = "last_donation";
    public static final String COL_USER_AVAILABLE     = "is_available";
    public static final String COL_USER_TOTAL_DON     = "total_donations";
    public static final String COL_USER_POINTS        = "points";

    public static final String COL_REQ_ID          = "id";
    public static final String COL_REQ_UID         = "request_uid";
    public static final String COL_REQ_NAME        = "requester_name";
    public static final String COL_REQ_PHONE       = "phone";
    public static final String COL_REQ_BLOOD_GROUP = "blood_group";
    public static final String COL_REQ_HOSPITAL    = "hospital_name";
    public static final String COL_REQ_DATETIME    = "required_datetime";
    public static final String COL_REQ_PRIORITY    = "priority";
    public static final String COL_REQ_LATITUDE    = "latitude";
    public static final String COL_REQ_LONGITUDE   = "longitude";
    public static final String COL_REQ_POSTED_DATE = "posted_date";
    public static final String COL_REQ_POSTED_BY   = "posted_by_uid";

    public static final String COL_HIST_ID         = "id";
    public static final String COL_HIST_USER_UID   = "user_uid";
    public static final String COL_HIST_DATE       = "date";
    public static final String COL_HIST_HOSPITAL   = "hospital";
    public static final String COL_HIST_UNITS      = "units_given";
    public static final String COL_HIST_BLOOD_GROUP = "blood_group";

    private static final String CREATE_TABLE_USERS =
            "CREATE TABLE " + TABLE_USERS + " ("
                    + COL_USER_ID            + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                    + COL_USER_UID           + " TEXT UNIQUE, "
                    + COL_USER_NAME          + " TEXT NOT NULL, "
                    + COL_USER_EMAIL         + " TEXT UNIQUE NOT NULL, "
                    + COL_USER_PHONE         + " TEXT, "
                    + COL_USER_PASSWORD      + " TEXT NOT NULL, "
                    + COL_USER_BLOOD_GROUP   + " TEXT, "
                    + COL_USER_TYPE          + " TEXT DEFAULT 'Donor', "
                    + COL_USER_LATITUDE      + " REAL DEFAULT 0.0, "
                    + COL_USER_LONGITUDE     + " REAL DEFAULT 0.0, "
                    + COL_USER_LAST_DONATION + " TEXT DEFAULT 'Not donated yet', "
                    + COL_USER_AVAILABLE     + " INTEGER DEFAULT 1, "
                    + COL_USER_TOTAL_DON     + " INTEGER DEFAULT 0, "
                    + COL_USER_POINTS        + " INTEGER DEFAULT 0"
                    + ");";

    private static final String CREATE_TABLE_BLOOD_REQUESTS =
            "CREATE TABLE " + TABLE_BLOOD_REQUESTS + " ("
                    + COL_REQ_ID          + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                    + COL_REQ_UID         + " TEXT UNIQUE, "
                    + COL_REQ_NAME        + " TEXT NOT NULL, "
                    + COL_REQ_PHONE       + " TEXT, "
                    + COL_REQ_BLOOD_GROUP + " TEXT NOT NULL, "
                    + COL_REQ_HOSPITAL    + " TEXT NOT NULL, "
                    + COL_REQ_DATETIME    + " TEXT, "
                    + COL_REQ_PRIORITY    + " TEXT DEFAULT 'Normal', "
                    + COL_REQ_LATITUDE    + " REAL DEFAULT 0.0, "
                    + COL_REQ_LONGITUDE   + " REAL DEFAULT 0.0, "
                    + COL_REQ_POSTED_DATE + " TEXT, "
                    + COL_REQ_POSTED_BY   + " TEXT"
                    + ");";

    private static final String CREATE_TABLE_DONATION_HISTORY =
            "CREATE TABLE " + TABLE_DONATION_HISTORY + " ("
                    + COL_HIST_ID         + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                    + COL_HIST_USER_UID   + " TEXT NOT NULL, "
                    + COL_HIST_DATE       + " TEXT NOT NULL, "
                    + COL_HIST_HOSPITAL   + " TEXT NOT NULL, "
                    + COL_HIST_UNITS      + " TEXT DEFAULT '1 Unit (450ml)', "
                    + COL_HIST_BLOOD_GROUP + " TEXT"
                    + ");";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE_USERS);
        db.execSQL(CREATE_TABLE_BLOOD_REQUESTS);
        db.execSQL(CREATE_TABLE_DONATION_HISTORY);
        seedSampleData(db);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_BLOOD_REQUESTS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_DONATION_HISTORY);
        onCreate(db);
    }

    private void seedSampleData(SQLiteDatabase db) {
        String[] donors = {
                "('USR001','Rahul Sharma','rahul@gmail.com','9876543210','pass','A+','Donor',23.0225,72.5714,'10 Jan 2024',1,5,500)",
                "('USR002','Priya Patel','priya@gmail.com','9876543211','pass','O+','Donor',23.0300,72.5800,'05 Feb 2024',1,3,300)",
                "('USR003','Amit Kumar','amit@gmail.com','9876543212','pass','B+','Donor',23.0150,72.5650,'20 Dec 2023',0,7,700)",
                "('USR004','Sneha Desai','sneha@gmail.com','9876543213','pass','AB+','Donor',23.0400,72.5900,'15 Mar 2024',1,2,200)",
                "('USR005','Vikram Singh','vikram@gmail.com','9876543214','pass','O-','Donor',23.0100,72.5600,'01 Jan 2024',1,10,1000)",
                "('USR006','Kavya Mehta','kavya@gmail.com','9876543215','pass','A-','Donor',23.0500,72.6000,'25 Nov 2023',0,4,400)",
                "('USR007','Ravi Joshi','ravi@gmail.com','9876543216','pass','B-','Donor',23.0350,72.5750,'10 Mar 2024',1,1,100)",
                "('USR008','Ananya Shah','ananya@gmail.com','9876543217','pass','AB-','Donor',23.0250,72.5700,'20 Feb 2024',1,6,600)",
                "('USR009','Deepak Modi','deepak@gmail.com','9876543218','pass','O+','Donor',23.0180,72.5680,'05 Jan 2024',1,8,800)",
                "('USR010','Meena Gupta','meena@gmail.com','9876543219','pass','A+','Donor',23.0290,72.5770,'28 Feb 2024',0,12,1200)"
        };

        for (String values : donors) {
            db.execSQL("INSERT OR IGNORE INTO " + TABLE_USERS
                    + " (uid,full_name,email,phone,password,blood_group,user_type,"
                    + "latitude,longitude,last_donation,is_available,total_donations,points) VALUES "
                    + values + ";");
        }

        String[] requests = {
                "('REQ001','Suresh Patel','9123456780','O+','Civil Hospital, Ahmedabad','06 Apr 2024, 10:00 AM','Critical',23.0225,72.5714,'05 Apr 2024','USR_DEMO')",
                "('REQ002','Nita Shah','9123456781','A+','Sterling Hospital, Ahmedabad','07 Apr 2024, 2:00 PM','Urgent',23.0300,72.5800,'05 Apr 2024','USR_DEMO')",
                "('REQ003','Ramesh Kumar','9123456782','B+','SAL Hospital, Ahmedabad','08 Apr 2024, 9:00 AM','Normal',23.0150,72.5650,'04 Apr 2024','USR_DEMO')",
                "('REQ004','Geeta Patel','9123456783','AB-','Apollo Hospital, Ahmedabad','06 Apr 2024, 5:00 PM','Critical',23.0400,72.5900,'05 Apr 2024','USR_DEMO')",
                "('REQ005','Dinesh Verma','9123456784','O-','CIMS Hospital, Ahmedabad','09 Apr 2024, 11:00 AM','Urgent',23.0100,72.5600,'06 Apr 2024','USR_DEMO')"
        };

        for (String values : requests) {
            db.execSQL("INSERT OR IGNORE INTO " + TABLE_BLOOD_REQUESTS
                    + " (request_uid,requester_name,phone,blood_group,hospital_name,"
                    + "required_datetime,priority,latitude,longitude,posted_date,posted_by_uid) VALUES "
                    + values + ";");
        }

        String[] history = {
                "('USR001','10 Jan 2024','Civil Hospital, Ahmedabad','1 Unit (450ml)','A+')",
                "('USR001','15 Sep 2023','Sterling Hospital, Ahmedabad','1 Unit (450ml)','A+')",
                "('USR001','20 May 2023','SAL Hospital, Ahmedabad','1 Unit (450ml)','A+')"
        };

        for (String values : history) {
            db.execSQL("INSERT OR IGNORE INTO " + TABLE_DONATION_HISTORY
                    + " (user_uid,date,hospital,units_given,blood_group) VALUES "
                    + values + ";");
        }
    }
}
